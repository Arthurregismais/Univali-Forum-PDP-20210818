﻿
namespace CalculadoraForumTemático
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN1 = new System.Windows.Forms.Button();
            this.BTN2 = new System.Windows.Forms.Button();
            this.BTN3 = new System.Windows.Forms.Button();
            this.BTN4 = new System.Windows.Forms.Button();
            this.BTN5 = new System.Windows.Forms.Button();
            this.BTN6 = new System.Windows.Forms.Button();
            this.BTN7 = new System.Windows.Forms.Button();
            this.BTN8 = new System.Windows.Forms.Button();
            this.BTN9 = new System.Windows.Forms.Button();
            this.BTN0 = new System.Windows.Forms.Button();
            this.BTN_virgula = new System.Windows.Forms.Button();
            this.BTN_somar = new System.Windows.Forms.Button();
            this.BTN_subtrair = new System.Windows.Forms.Button();
            this.BTN_multiplicar = new System.Windows.Forms.Button();
            this.BTN_dividir = new System.Windows.Forms.Button();
            this.BTN_igualar = new System.Windows.Forms.Button();
            this.BTN_limpar = new System.Windows.Forms.Button();
            this.txt_valor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BTN1
            // 
            this.BTN1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN1.Location = new System.Drawing.Point(6, 55);
            this.BTN1.Name = "BTN1";
            this.BTN1.Size = new System.Drawing.Size(67, 61);
            this.BTN1.TabIndex = 0;
            this.BTN1.Text = "1";
            this.BTN1.UseVisualStyleBackColor = true;
            this.BTN1.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN2
            // 
            this.BTN2.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN2.Location = new System.Drawing.Point(79, 55);
            this.BTN2.Name = "BTN2";
            this.BTN2.Size = new System.Drawing.Size(67, 61);
            this.BTN2.TabIndex = 1;
            this.BTN2.Text = "2";
            this.BTN2.UseVisualStyleBackColor = true;
            this.BTN2.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN3
            // 
            this.BTN3.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN3.Location = new System.Drawing.Point(152, 55);
            this.BTN3.Name = "BTN3";
            this.BTN3.Size = new System.Drawing.Size(67, 61);
            this.BTN3.TabIndex = 2;
            this.BTN3.Text = "3";
            this.BTN3.UseVisualStyleBackColor = true;
            this.BTN3.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN4
            // 
            this.BTN4.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN4.Location = new System.Drawing.Point(6, 122);
            this.BTN4.Name = "BTN4";
            this.BTN4.Size = new System.Drawing.Size(67, 61);
            this.BTN4.TabIndex = 3;
            this.BTN4.Text = "4";
            this.BTN4.UseVisualStyleBackColor = true;
            this.BTN4.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN5
            // 
            this.BTN5.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN5.Location = new System.Drawing.Point(79, 122);
            this.BTN5.Name = "BTN5";
            this.BTN5.Size = new System.Drawing.Size(67, 61);
            this.BTN5.TabIndex = 4;
            this.BTN5.Text = "5";
            this.BTN5.UseVisualStyleBackColor = true;
            this.BTN5.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN6
            // 
            this.BTN6.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN6.Location = new System.Drawing.Point(152, 122);
            this.BTN6.Name = "BTN6";
            this.BTN6.Size = new System.Drawing.Size(67, 61);
            this.BTN6.TabIndex = 5;
            this.BTN6.Text = "6";
            this.BTN6.UseVisualStyleBackColor = true;
            this.BTN6.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN7
            // 
            this.BTN7.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN7.Location = new System.Drawing.Point(6, 189);
            this.BTN7.Name = "BTN7";
            this.BTN7.Size = new System.Drawing.Size(67, 61);
            this.BTN7.TabIndex = 6;
            this.BTN7.Text = "7";
            this.BTN7.UseVisualStyleBackColor = true;
            this.BTN7.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN8
            // 
            this.BTN8.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN8.Location = new System.Drawing.Point(79, 189);
            this.BTN8.Name = "BTN8";
            this.BTN8.Size = new System.Drawing.Size(67, 61);
            this.BTN8.TabIndex = 7;
            this.BTN8.Text = "8";
            this.BTN8.UseVisualStyleBackColor = true;
            this.BTN8.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN9
            // 
            this.BTN9.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN9.Location = new System.Drawing.Point(152, 189);
            this.BTN9.Name = "BTN9";
            this.BTN9.Size = new System.Drawing.Size(67, 61);
            this.BTN9.TabIndex = 8;
            this.BTN9.Text = "9";
            this.BTN9.UseVisualStyleBackColor = true;
            this.BTN9.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN0
            // 
            this.BTN0.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN0.Location = new System.Drawing.Point(6, 256);
            this.BTN0.Name = "BTN0";
            this.BTN0.Size = new System.Drawing.Size(140, 61);
            this.BTN0.TabIndex = 9;
            this.BTN0.Text = "0";
            this.BTN0.UseVisualStyleBackColor = true;
            this.BTN0.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN_virgula
            // 
            this.BTN_virgula.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_virgula.Location = new System.Drawing.Point(152, 256);
            this.BTN_virgula.Name = "BTN_virgula";
            this.BTN_virgula.Size = new System.Drawing.Size(67, 61);
            this.BTN_virgula.TabIndex = 10;
            this.BTN_virgula.Text = ",";
            this.BTN_virgula.UseVisualStyleBackColor = true;
            this.BTN_virgula.Click += new System.EventHandler(this.BTNnumerador_Click);
            // 
            // BTN_somar
            // 
            this.BTN_somar.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_somar.Location = new System.Drawing.Point(226, 122);
            this.BTN_somar.Name = "BTN_somar";
            this.BTN_somar.Size = new System.Drawing.Size(85, 61);
            this.BTN_somar.TabIndex = 11;
            this.BTN_somar.Text = "+";
            this.BTN_somar.UseVisualStyleBackColor = true;
            this.BTN_somar.Click += new System.EventHandler(this.BTN_somar_Click);
            // 
            // BTN_subtrair
            // 
            this.BTN_subtrair.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_subtrair.Location = new System.Drawing.Point(317, 122);
            this.BTN_subtrair.Name = "BTN_subtrair";
            this.BTN_subtrair.Size = new System.Drawing.Size(81, 61);
            this.BTN_subtrair.TabIndex = 12;
            this.BTN_subtrair.Text = "-";
            this.BTN_subtrair.UseVisualStyleBackColor = true;
            this.BTN_subtrair.Click += new System.EventHandler(this.BTN_subtrair_Click);
            // 
            // BTN_multiplicar
            // 
            this.BTN_multiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_multiplicar.Location = new System.Drawing.Point(226, 189);
            this.BTN_multiplicar.Name = "BTN_multiplicar";
            this.BTN_multiplicar.Size = new System.Drawing.Size(85, 61);
            this.BTN_multiplicar.TabIndex = 13;
            this.BTN_multiplicar.Text = "*";
            this.BTN_multiplicar.UseVisualStyleBackColor = true;
            this.BTN_multiplicar.Click += new System.EventHandler(this.BTN_multiplicar_Click);
            // 
            // BTN_dividir
            // 
            this.BTN_dividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_dividir.Location = new System.Drawing.Point(317, 189);
            this.BTN_dividir.Name = "BTN_dividir";
            this.BTN_dividir.Size = new System.Drawing.Size(81, 61);
            this.BTN_dividir.TabIndex = 14;
            this.BTN_dividir.Text = "/";
            this.BTN_dividir.UseVisualStyleBackColor = true;
            this.BTN_dividir.Click += new System.EventHandler(this.BTN_dividir_Click);
            // 
            // BTN_igualar
            // 
            this.BTN_igualar.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_igualar.Location = new System.Drawing.Point(226, 256);
            this.BTN_igualar.Name = "BTN_igualar";
            this.BTN_igualar.Size = new System.Drawing.Size(172, 61);
            this.BTN_igualar.TabIndex = 15;
            this.BTN_igualar.Text = "=";
            this.BTN_igualar.UseVisualStyleBackColor = true;
            this.BTN_igualar.Click += new System.EventHandler(this.BTN_igualar_Click);
            // 
            // BTN_limpar
            // 
            this.BTN_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_limpar.Location = new System.Drawing.Point(226, 55);
            this.BTN_limpar.Name = "BTN_limpar";
            this.BTN_limpar.Size = new System.Drawing.Size(172, 61);
            this.BTN_limpar.TabIndex = 16;
            this.BTN_limpar.Text = "C";
            this.BTN_limpar.UseVisualStyleBackColor = true;
            this.BTN_limpar.Click += new System.EventHandler(this.BTN_limpar_Click);
            // 
            // txt_valor
            // 
            this.txt_valor.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_valor.Location = new System.Drawing.Point(4, 8);
            this.txt_valor.Name = "txt_valor";
            this.txt_valor.Size = new System.Drawing.Size(394, 41);
            this.txt_valor.TabIndex = 17;
            this.txt_valor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 26);
            this.label1.TabIndex = 18;
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 341);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_valor);
            this.Controls.Add(this.BTN_limpar);
            this.Controls.Add(this.BTN_igualar);
            this.Controls.Add(this.BTN_dividir);
            this.Controls.Add(this.BTN_multiplicar);
            this.Controls.Add(this.BTN_subtrair);
            this.Controls.Add(this.BTN_somar);
            this.Controls.Add(this.BTN_virgula);
            this.Controls.Add(this.BTN0);
            this.Controls.Add(this.BTN9);
            this.Controls.Add(this.BTN8);
            this.Controls.Add(this.BTN7);
            this.Controls.Add(this.BTN6);
            this.Controls.Add(this.BTN5);
            this.Controls.Add(this.BTN4);
            this.Controls.Add(this.BTN3);
            this.Controls.Add(this.BTN2);
            this.Controls.Add(this.BTN1);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTN1;
        private System.Windows.Forms.Button BTN2;
        private System.Windows.Forms.Button BTN3;
        private System.Windows.Forms.Button BTN4;
        private System.Windows.Forms.Button BTN5;
        private System.Windows.Forms.Button BTN6;
        private System.Windows.Forms.Button BTN7;
        private System.Windows.Forms.Button BTN8;
        private System.Windows.Forms.Button BTN9;
        private System.Windows.Forms.Button BTN0;
        private System.Windows.Forms.Button BTN_virgula;
        private System.Windows.Forms.Button BTN_somar;
        private System.Windows.Forms.Button BTN_subtrair;
        private System.Windows.Forms.Button BTN_multiplicar;
        private System.Windows.Forms.Button BTN_dividir;
        private System.Windows.Forms.Button BTN_igualar;
        private System.Windows.Forms.Button BTN_limpar;
        private System.Windows.Forms.TextBox txt_valor;
        private System.Windows.Forms.Label label1;
    }
}

